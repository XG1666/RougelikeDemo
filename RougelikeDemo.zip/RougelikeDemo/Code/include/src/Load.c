#include<stdio.h>

#include"../Character.h"

void L_loadInit(void)
{
}